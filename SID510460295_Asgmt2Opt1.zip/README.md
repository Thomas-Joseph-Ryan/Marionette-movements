# How to run

### Data Extraction

Using the intelligent_animation.ipynb, you can run the data extraction section of the assignment. Just follow the cells and run them in order. Ensure that you have all of the necessary directories available in your directory:
movie_frames
movie_frames_with_centers
movie_frames_with_centers_labelled

### Animation

In order to run the animated program, open the animation.pde file with the processing application. Ensure you have Minim installed as a dependency then press the play button in the top left.
